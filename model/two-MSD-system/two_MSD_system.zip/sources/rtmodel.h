#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "two_MSD_system.h"
#define GRTINTERFACE                   0
#endif
