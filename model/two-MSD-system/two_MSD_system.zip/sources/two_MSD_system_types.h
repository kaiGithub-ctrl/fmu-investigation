#ifndef RTW_HEADER_two_MSD_system_types_h_
#define RTW_HEADER_two_MSD_system_types_h_

typedef struct P_two_MSD_system_T_ P_two_MSD_system_T;
typedef struct tag_RTM_two_MSD_system_T RT_MODEL_two_MSD_system_T;

#endif
